#!/bin/bash
bash <(curl -v http://localhost:3000/photo/1)