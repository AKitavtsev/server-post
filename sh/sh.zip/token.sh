#!/bin/bash
bash <(curl -v "http://localhost:3000/token/?login=KIT&password=KIT0000")