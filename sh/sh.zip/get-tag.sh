#!/bin/bash
bash <(curl -v http://localhost:3000/tag/1.120210901202553ff034f3847c1d22f091dde7cde045264/1)